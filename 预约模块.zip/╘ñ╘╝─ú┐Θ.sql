/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 80028
Source Host           : localhost:3306
Source Database       : example

Target Server Type    : MYSQL
Target Server Version : 80028
File Encoding         : 65001

Date: 2022-04-11 19:35:20
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for bookings
-- ----------------------------
DROP TABLE IF EXISTS `bookings`;
CREATE TABLE `bookings` (
  `BookingID` int NOT NULL AUTO_INCREMENT COMMENT '预约ID',
  `ScheduleID` int DEFAULT NULL COMMENT '课表ID',
  `StudentNO` char(12) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户ID',
  `BookingDate` datetime DEFAULT NULL,
  `BookingStatus` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '预约状况：0取消预约，1预约，2已签到，3未签到',
  `LabID` smallint DEFAULT NULL,
  `ProjectID` smallint DEFAULT NULL,
  `SubjectID` smallint DEFAULT NULL,
  PRIMARY KEY (`BookingID`),
  UNIQUE KEY `book_uid_cid` (`ScheduleID`,`StudentNO`) USING BTREE COMMENT '用户id+课表id的唯一索引'
) ENGINE=InnoDB AUTO_INCREMENT=1471 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of bookings
-- ----------------------------
INSERT INTO `bookings` VALUES ('1464', '1', '1', '2022-04-09 19:13:17', '1', '1', '1', '1');
INSERT INTO `bookings` VALUES ('1465', '2', '1', '2022-04-09 19:13:21', '1', '2', '1', '2');
INSERT INTO `bookings` VALUES ('1466', '3', '1', '2022-04-09 19:13:25', '1', '1', '1', '1');
INSERT INTO `bookings` VALUES ('1467', '4', '1', '2022-04-09 19:13:30', '1', '3', '2', '3');
INSERT INTO `bookings` VALUES ('1468', '1', '2', '2022-04-09 19:20:34', '1', '1', '1', '1');
INSERT INTO `bookings` VALUES ('1469', '2', '2', '2022-04-09 19:20:38', '1', '2', '1', '2');
INSERT INTO `bookings` VALUES ('1470', '4', '2', '2022-04-09 19:20:42', '1', '3', '2', '3');

-- ----------------------------
-- Table structure for projects
-- ----------------------------
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `ProjectID` smallint NOT NULL COMMENT '项目ID',
  `CourseID` smallint DEFAULT NULL,
  `ProjectTitle` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '项目名称',
  PRIMARY KEY (`ProjectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of projects
-- ----------------------------
INSERT INTO `projects` VALUES ('1', '1', '电学');
INSERT INTO `projects` VALUES ('2', '2', '力学');

-- ----------------------------
-- Table structure for schedules
-- ----------------------------
DROP TABLE IF EXISTS `schedules`;
CREATE TABLE `schedules` (
  `ScheduleID` int NOT NULL COMMENT '课表ID',
  `CourseID` smallint DEFAULT NULL,
  `SubjectID` smallint DEFAULT NULL COMMENT '题目ID',
  `LabID` smallint DEFAULT NULL COMMENT '实验室ID',
  `TeacherID` smallint DEFAULT NULL COMMENT '教师ID',
  `RemainQuantity` smallint unsigned DEFAULT NULL COMMENT '剩余数量',
  `UpperQuantity` smallint DEFAULT NULL COMMENT '上限数量',
  `IsReleased` tinyint DEFAULT NULL COMMENT '发布状态',
  `StartTime` datetime DEFAULT NULL COMMENT '开始时间',
  `EndTime` datetime DEFAULT NULL COMMENT '结束时间',
  PRIMARY KEY (`ScheduleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of schedules
-- ----------------------------
INSERT INTO `schedules` VALUES ('1', null, '1', '1', '1', '38', '40', '1', '2022-04-07 18:42:54', '2022-04-07 18:42:59');
INSERT INTO `schedules` VALUES ('2', null, '2', '2', '2', '7', '10', '1', '2022-04-08 18:43:01', null);
INSERT INTO `schedules` VALUES ('3', null, '1', '1', '3', '0', '10', '1', '2022-04-09 18:43:06', null);
INSERT INTO `schedules` VALUES ('4', null, '3', '3', '4', '7', '10', '1', '2022-04-30 21:21:24', null);
INSERT INTO `schedules` VALUES ('5', null, '1', '1', '5', '10', '10', '0', null, null);

-- ----------------------------
-- Table structure for subjects
-- ----------------------------
DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `ProjectID` smallint DEFAULT NULL COMMENT '项目ID',
  `SubjectID` tinyint NOT NULL COMMENT '题目ID',
  `SubjectTitle` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '题目名称',
  PRIMARY KEY (`SubjectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of subjects
-- ----------------------------
INSERT INTO `subjects` VALUES ('1', '1', '测电阻');
INSERT INTO `subjects` VALUES ('1', '2', '自组电桥');
INSERT INTO `subjects` VALUES ('2', '3', '重力加速度');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint NOT NULL COMMENT '用户ID,手机号码',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL COMMENT 'MD5(MD5(pass明文+固定salt)+salt)',
  `salt` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('0', 'user0', '1', null);
INSERT INTO `user` VALUES ('1', 'admin', '1', null);
INSERT INTO `user` VALUES ('2', 'user2', '1', null);
INSERT INTO `user` VALUES ('3', 'user3', '1', null);
INSERT INTO `user` VALUES ('4', 'user4', '1', null);
INSERT INTO `user` VALUES ('5', 'user5', '1', null);
INSERT INTO `user` VALUES ('6', 'user6', '1', null);
INSERT INTO `user` VALUES ('7', 'user7', '1', null);
INSERT INTO `user` VALUES ('8', 'user8', '1', null);
INSERT INTO `user` VALUES ('9', 'user9', '1', null);
INSERT INTO `user` VALUES ('10', 'user10', '1', null);
INSERT INTO `user` VALUES ('11', 'user11', '1', null);
INSERT INTO `user` VALUES ('12', 'user12', '1', null);
INSERT INTO `user` VALUES ('13', 'user13', '1', null);
INSERT INTO `user` VALUES ('14', 'user14', '1', null);
INSERT INTO `user` VALUES ('15', 'user15', '1', null);
INSERT INTO `user` VALUES ('16', 'user16', '1', null);
INSERT INTO `user` VALUES ('17', 'user17', '1', null);
INSERT INTO `user` VALUES ('18', 'user18', '1', null);
INSERT INTO `user` VALUES ('19', 'user19', '1', null);
INSERT INTO `user` VALUES ('20', 'user20', '1', null);
INSERT INTO `user` VALUES ('21', 'user21', '1', null);
INSERT INTO `user` VALUES ('22', 'user22', '1', null);
INSERT INTO `user` VALUES ('23', 'user23', '1', null);
INSERT INTO `user` VALUES ('24', 'user24', '1', null);
INSERT INTO `user` VALUES ('25', 'user25', '1', null);
INSERT INTO `user` VALUES ('26', 'user26', '1', null);
INSERT INTO `user` VALUES ('27', 'user27', '1', null);
INSERT INTO `user` VALUES ('28', 'user28', '1', null);
INSERT INTO `user` VALUES ('29', 'user29', '1', null);
INSERT INTO `user` VALUES ('30', 'user30', '1', null);
INSERT INTO `user` VALUES ('31', 'user31', '1', null);
INSERT INTO `user` VALUES ('32', 'user32', '1', null);
INSERT INTO `user` VALUES ('33', 'user33', '1', null);
INSERT INTO `user` VALUES ('34', 'user34', '1', null);
INSERT INTO `user` VALUES ('35', 'user35', '1', null);
INSERT INTO `user` VALUES ('36', 'user36', '1', null);
INSERT INTO `user` VALUES ('37', 'user37', '1', null);
INSERT INTO `user` VALUES ('38', 'user38', '1', null);
INSERT INTO `user` VALUES ('39', 'user39', '1', null);
INSERT INTO `user` VALUES ('40', 'user40', '1', null);
INSERT INTO `user` VALUES ('41', 'user41', '1', null);
INSERT INTO `user` VALUES ('42', 'user42', '1', null);
INSERT INTO `user` VALUES ('43', 'user43', '1', null);
INSERT INTO `user` VALUES ('44', 'user44', '1', null);
INSERT INTO `user` VALUES ('45', 'user45', '1', null);
INSERT INTO `user` VALUES ('46', 'user46', '1', null);
INSERT INTO `user` VALUES ('47', 'user47', '1', null);
INSERT INTO `user` VALUES ('48', 'user48', '1', null);
INSERT INTO `user` VALUES ('49', 'user49', '1', null);
INSERT INTO `user` VALUES ('50', 'user50', '1', null);
INSERT INTO `user` VALUES ('51', 'user51', '1', null);
INSERT INTO `user` VALUES ('52', 'user52', '1', null);
INSERT INTO `user` VALUES ('53', 'user53', '1', null);
INSERT INTO `user` VALUES ('54', 'user54', '1', null);
INSERT INTO `user` VALUES ('55', 'user55', '1', null);
INSERT INTO `user` VALUES ('56', 'user56', '1', null);
INSERT INTO `user` VALUES ('57', 'user57', '1', null);
INSERT INTO `user` VALUES ('58', 'user58', '1', null);
INSERT INTO `user` VALUES ('59', 'user59', '1', null);
INSERT INTO `user` VALUES ('60', 'user60', '1', null);
INSERT INTO `user` VALUES ('61', 'user61', '1', null);
INSERT INTO `user` VALUES ('62', 'user62', '1', null);
INSERT INTO `user` VALUES ('63', 'user63', '1', null);
INSERT INTO `user` VALUES ('64', 'user64', '1', null);
INSERT INTO `user` VALUES ('65', 'user65', '1', null);
INSERT INTO `user` VALUES ('66', 'user66', '1', null);
INSERT INTO `user` VALUES ('67', 'user67', '1', null);
INSERT INTO `user` VALUES ('68', 'user68', '1', null);
INSERT INTO `user` VALUES ('69', 'user69', '1', null);
INSERT INTO `user` VALUES ('70', 'user70', '1', null);
INSERT INTO `user` VALUES ('71', 'user71', '1', null);
INSERT INTO `user` VALUES ('72', 'user72', '1', null);
INSERT INTO `user` VALUES ('73', 'user73', '1', null);
INSERT INTO `user` VALUES ('74', 'user74', '1', null);
INSERT INTO `user` VALUES ('75', 'user75', '1', null);
INSERT INTO `user` VALUES ('76', 'user76', '1', null);
INSERT INTO `user` VALUES ('77', 'user77', '1', null);
INSERT INTO `user` VALUES ('78', 'user78', '1', null);
INSERT INTO `user` VALUES ('79', 'user79', '1', null);
INSERT INTO `user` VALUES ('80', 'user80', '1', null);
INSERT INTO `user` VALUES ('81', 'user81', '1', null);
INSERT INTO `user` VALUES ('82', 'user82', '1', null);
INSERT INTO `user` VALUES ('83', 'user83', '1', null);
INSERT INTO `user` VALUES ('84', 'user84', '1', null);
INSERT INTO `user` VALUES ('85', 'user85', '1', null);
INSERT INTO `user` VALUES ('86', 'user86', '1', null);
INSERT INTO `user` VALUES ('87', 'user87', '1', null);
INSERT INTO `user` VALUES ('88', 'user88', '1', null);
INSERT INTO `user` VALUES ('89', 'user89', '1', null);
INSERT INTO `user` VALUES ('90', 'user90', '1', null);
INSERT INTO `user` VALUES ('91', 'user91', '1', null);
INSERT INTO `user` VALUES ('92', 'user92', '1', null);
INSERT INTO `user` VALUES ('93', 'user93', '1', null);
INSERT INTO `user` VALUES ('94', 'user94', '1', null);
INSERT INTO `user` VALUES ('95', 'user95', '1', null);
INSERT INTO `user` VALUES ('96', 'user96', '1', null);
INSERT INTO `user` VALUES ('97', 'user97', '1', null);
INSERT INTO `user` VALUES ('98', 'user98', '1', null);
INSERT INTO `user` VALUES ('99', 'user99', '1', null);
