package com.mbp.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mbp.example.pojo.Bookings;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Alark
 */
public interface BookingsMapper extends BaseMapper<Bookings> {

}
