package com.mbp.example.service.impl;

import com.mbp.example.exeception.GlobalException;
import com.mbp.example.mapper.UserMapper;
import com.mbp.example.pojo.User;
import com.mbp.example.service.ILoginService;
import com.mbp.example.utils.CookieUtil;
import com.mbp.example.utils.UUIDUtil;
import com.mbp.example.vo.LoginVo;
import com.mbp.example.vo.RespBean;
import com.mbp.example.vo.RespBeanEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Service
public class LoginServiceImpl implements ILoginService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public RespBean doLogin(LoginVo loginVo, HttpServletRequest request, HttpServletResponse response) {
        String mobile = loginVo.getMobile();
        String password = loginVo.getPassword();
        User user = userMapper.selectById(mobile);
        //判断用户存在和密码是否正确
        if (user == null || !password.equals(user.getPassword())) {
            throw new GlobalException(RespBeanEnum.LOGIN_ERROR);
        }
        //生成Cookie
        String ticket = UUIDUtil.uuid();
        redisTemplate.opsForValue().set("user:" + ticket, user);
        CookieUtil.setCookie(request, response, "userTicket", ticket);
        return RespBean.success(ticket);
    }
}
