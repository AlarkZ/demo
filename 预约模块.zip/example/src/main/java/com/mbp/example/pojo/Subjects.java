package com.mbp.example.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <p>
 * Subject题目
 * </p>
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Subjects implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 项目ID
     */
    @TableField("ProjectID")
    private Integer ProjectID;

    /**
     * 题目ID
     */
    @TableId("SubjectID")
    private Integer SubjectID;

    /**
     * 题目名称
     */
    @TableField("SubjectTitle")
    private String SubjectTitle;


}
