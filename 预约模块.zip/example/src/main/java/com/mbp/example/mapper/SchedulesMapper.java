package com.mbp.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mbp.example.pojo.Schedules;
import com.mbp.example.vo.BookVo;
import com.mbp.example.vo.SchedulesVo;

import java.util.List;

public interface SchedulesMapper extends BaseMapper<Schedules> {

    List<SchedulesVo> findSchedulesVo();

    SchedulesVo findSchedulesVoById(Integer scheduleID);

    List<BookVo> findBookVoByCheck(Long userId);

    List<BookVo> findBookVoByEdit(Long userId);
}
