package com.mbp.example.exeception;

import com.mbp.example.vo.RespBeanEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 全局异常
 */
@Data
@NoArgsConstructor //无参构造
@AllArgsConstructor //全参构造
public class GlobalException extends RuntimeException{

    private RespBeanEnum respBeanEnum;

}
