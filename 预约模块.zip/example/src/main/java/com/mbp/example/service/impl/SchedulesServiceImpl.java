package com.mbp.example.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mbp.example.mapper.SchedulesMapper;
import com.mbp.example.pojo.Schedules;
import com.mbp.example.pojo.User;
import com.mbp.example.service.ISchedulesService;
import com.mbp.example.vo.BookVo;
import com.mbp.example.vo.SchedulesVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SchedulesServiceImpl extends ServiceImpl<SchedulesMapper, Schedules> implements ISchedulesService {
    @Autowired
    private SchedulesMapper schedulesMapper;

    @Override
    public List<SchedulesVo> findSchedulesVo() {//获取课表
        return schedulesMapper.findSchedulesVo();
    }

    @Override
    public SchedulesVo findSchedulesVoById(Integer scheduleID) {
        return schedulesMapper.findSchedulesVoById(scheduleID);
    }

    @Override
    public List<BookVo> findBookVoByCheck(User user) {
        return schedulesMapper.findBookVoByCheck(user.getId());
    }

    @Override
    public List<BookVo> findBookVoByEdit(User user) {
        return schedulesMapper.findBookVoByEdit(user.getId());
    }

}
