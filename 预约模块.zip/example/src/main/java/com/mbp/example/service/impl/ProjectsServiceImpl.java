package com.mbp.example.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mbp.example.mapper.ProjectsMapper;
import com.mbp.example.pojo.Projects;
import com.mbp.example.service.IProjectsService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Alark
 */
@Service
public class ProjectsServiceImpl extends ServiceImpl<ProjectsMapper, Projects> implements IProjectsService {

}
