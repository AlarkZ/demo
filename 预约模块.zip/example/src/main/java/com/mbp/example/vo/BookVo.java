package com.mbp.example.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookVo extends SchedulesVo {
    private String bookingStatus;
    private String statusTitle;
}
