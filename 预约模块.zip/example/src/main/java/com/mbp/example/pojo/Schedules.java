package com.mbp.example.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Schedules implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 课表ID
     */
    @TableId("ScheduleID")
    private Integer ScheduleID;

    @TableField("CourseID")
    private Integer CourseID;

    /**
     * 题目ID
     */
    @TableField("SubjectID")
    private Integer SubjectID;

    /**
     * 实验室ID
     */
    @TableField("LabID")
    private Integer LabID;

    /**
     * 教师ID
     */
    @TableField("TeacherID")
    private Integer TeacherID;

    /**
     * 剩余数量
     */
    @TableField("RemainQuantity")
    private Integer RemainQuantity;

    /**
     * 上限数量
     */
    @TableField("UpperQuantity")
    private Integer UpperQuantity;

    /**
     * 发布状态
     */
    @TableField("IsReleased")
    private Integer IsReleased;

    /**
     * 开始时间
     */
    @TableField("StartTime")
    private Date StartTime;

    /**
     * 结束时间
     */
    @TableField("EndTime")
    private Date EndTime;


}
