package com.mbp.example.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mbp.example.mapper.BookingsMapper;
import com.mbp.example.pojo.Bookings;
import com.mbp.example.pojo.Schedules;
import com.mbp.example.pojo.User;
import com.mbp.example.service.IBookingsService;
import com.mbp.example.service.ISchedulesService;
import com.mbp.example.vo.SchedulesVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class BookingsServiceImpl extends ServiceImpl<BookingsMapper, Bookings> implements IBookingsService {

    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private BookingsMapper bookingsMapper;
    @Autowired
    private RedisTemplate redisTemplate;

    @Transactional
    @Override
    public Bookings book(User user, SchedulesVo schedulesVo) {
        Schedules updateSchedule = schedulesService.getOne(new QueryWrapper<Schedules>().eq("scheduleID", schedulesVo.getScheduleID()));
        updateSchedule.setRemainQuantity(updateSchedule.getRemainQuantity() - 1);

        boolean result = schedulesService.update(new UpdateWrapper<Schedules>()
                .setSql("RemainQuantity=" + "RemainQuantity-1")
                .eq("ScheduleID", schedulesVo.getScheduleID())
                .gt("RemainQuantity", 0));
        ValueOperations valueOperations = redisTemplate.opsForValue();
        if (result == false && updateSchedule.getRemainQuantity() < 1) {//更新失败且库存为0
            valueOperations.set("isStockEmpty:" + schedulesVo.getScheduleID(), "0");//用于查询结果
            return null;
        }

        Bookings bookings = new Bookings();
        bookings.setScheduleID(schedulesVo.getScheduleID());
        bookings.setStudentNO(String.valueOf(user.getId()));
        bookings.setBookingStatus("1");
        bookings.setProjectID(schedulesVo.getProjectID());
        bookings.setSubjectID(schedulesVo.getSubjectID());
        bookings.setBookingDate(new Date());
        bookings.setLabID(schedulesVo.getLabID());
        bookingsMapper.insert(bookings);

        valueOperations.set("booking:" + user.getId() + ":" + schedulesVo.getScheduleID(), bookings);

        return bookings;
    }

    @Override
    public Integer getResult(User user, Integer scheduleId) {
        Bookings bookings = bookingsMapper.selectOne(new QueryWrapper<Bookings>().eq("StudentNO", user.getId()).eq("ScheduleID", scheduleId));
        if (bookings != null) {
            return bookings.getBookingID();
        } else if (redisTemplate.hasKey("isStockEmpty:" + scheduleId)) {//最后一个预约存在问题
            return -1;
        } else {
            return 0;
        }
    }
}
