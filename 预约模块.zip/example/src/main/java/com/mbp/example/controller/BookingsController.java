package com.mbp.example.controller;


import com.mbp.example.pojo.BookMessage;
import com.mbp.example.pojo.Bookings;
import com.mbp.example.pojo.User;
import com.mbp.example.rabbitmq.MQSender;
import com.mbp.example.service.IBookingsService;
import com.mbp.example.service.ISchedulesService;
import com.mbp.example.utils.JsonUtil;
import com.mbp.example.vo.RespBean;
import com.mbp.example.vo.RespBeanEnum;
import com.mbp.example.vo.SchedulesVo;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/bookings")
public class BookingsController implements InitializingBean {
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private IBookingsService bookingsService;
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private MQSender mqSender;

    private volatile Map<Integer, Boolean> EmptyStockMap = new HashMap<>();

    @RequestMapping(value = "/doBook", method = RequestMethod.POST)
    @ResponseBody
    public RespBean doBook(Model model, User user, Integer scheduleId) {
        if (user == null) {
            return RespBean.error(RespBeanEnum.SESSION_ERROR);
        }

        if (EmptyStockMap.get(scheduleId)) {//内存标记存在漏洞
            return RespBean.error(RespBeanEnum.EMPTY_STOCK);
        }

        ValueOperations valueOperations = redisTemplate.opsForValue();
        Bookings repeatBook = (Bookings) valueOperations.get("booking:" + user.getId() + ":" + scheduleId);
        if (repeatBook != null) {//重复预约
            return RespBean.error(RespBeanEnum.REPEAT_ERROR, repeatBook);
        }
        //redis预减存在漏洞
        Long stock = valueOperations.decrement("schedules:" + scheduleId);
        if (stock < 0) {
            EmptyStockMap.put(scheduleId, true);
            valueOperations.increment("schedules:" + scheduleId);
            return RespBean.error(RespBeanEnum.EMPTY_STOCK);
        }
        BookMessage bookMessage = new BookMessage(user, scheduleId);
        mqSender.sendBookMessage(JsonUtil.object2JsonStr(bookMessage));
        return RespBean.success(0);

    }

    @RequestMapping(value = "/getResult", method = RequestMethod.GET)
    @ResponseBody
    public RespBean getResult(User user, Integer scheduleId) {
        if (user == null) {
            return RespBean.error(RespBeanEnum.SESSION_ERROR);
        }
        Integer bookId = bookingsService.getResult(user, scheduleId);
        return RespBean.success(bookId);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        List<SchedulesVo> list = schedulesService.findSchedulesVo();
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        list.forEach(schedulesVo -> {
            redisTemplate.opsForValue().set("schedules:" + schedulesVo.getScheduleID(), schedulesVo.getRemainQuantity());
            EmptyStockMap.put(schedulesVo.getScheduleID(), schedulesVo.getRemainQuantity() > 0 ? false : true);
        });
    }
}
