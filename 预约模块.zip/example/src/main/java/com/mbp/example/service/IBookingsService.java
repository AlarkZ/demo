package com.mbp.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mbp.example.pojo.Bookings;
import com.mbp.example.pojo.User;
import com.mbp.example.vo.SchedulesVo;

public interface IBookingsService extends IService<Bookings> {

    Bookings book(User user, SchedulesVo schedulesVo);

    Integer getResult(User user, Integer scheduleId);
}
