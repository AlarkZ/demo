package com.mbp.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mbp.example.pojo.Subjects;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Alark
 */
public interface SubjectsMapper extends BaseMapper<Subjects> {

}
