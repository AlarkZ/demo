package com.mbp.example.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <p>
 * Project项目
 * </p>
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Projects implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 项目ID
     */
    @TableId("ProjectID")
    private Integer ProjectID;

    @TableField("CourseID")
    private Integer CourseID;

    /**
     * 项目名称
     */
    @TableField("ProjectTitle")
    private String ProjectTitle;


}
