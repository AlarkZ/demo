package com.mbp.example.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Alark
 */
@Controller
@RequestMapping("/projects")
public class ProjectsController {

}
