package com.mbp.example.rabbitmq;

import com.mbp.example.pojo.BookMessage;
import com.mbp.example.pojo.Bookings;
import com.mbp.example.pojo.User;
import com.mbp.example.service.IBookingsService;
import com.mbp.example.service.ISchedulesService;
import com.mbp.example.utils.JsonUtil;
import com.mbp.example.vo.SchedulesVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * 消息消费者
 */
@Service
@Slf4j
public class MQReceiver {
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private IBookingsService bookingsService;

    @RabbitListener(queues = "Queue")
    public void receive(String message) {
        BookMessage bookMessage = JsonUtil.jsonStr2Object(message, BookMessage.class);
        Integer scheduleId = bookMessage.getScheduleId();
        User user = bookMessage.getUser();
        SchedulesVo schedulesVo = schedulesService.findSchedulesVoById(scheduleId);
        if (schedulesVo.getRemainQuantity() < 1) {
            return;
        }
        Bookings repeatBook = (Bookings) redisTemplate.opsForValue().get("booking:" + user.getId() + ":" + scheduleId);
        if (repeatBook != null) {
            return;
        }
        bookingsService.book(user, schedulesVo);
    }

}
