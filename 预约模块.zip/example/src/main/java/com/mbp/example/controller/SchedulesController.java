package com.mbp.example.controller;


import com.mbp.example.pojo.User;
import com.mbp.example.service.ISchedulesService;
import com.mbp.example.service.IUserService;
import com.mbp.example.vo.DetailVo;
import com.mbp.example.vo.RespBean;
import com.mbp.example.vo.SchedulesVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring5.view.ThymeleafViewResolver;
import org.thymeleaf.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.concurrent.TimeUnit;

@Controller
@RequestMapping("/schedules")
public class SchedulesController {
    @Autowired
    private IUserService userService;
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private ThymeleafViewResolver thymeleafViewResolver;

    /**
     * 功能描述: 跳转预约列表页
     */
    @RequestMapping(value = "/toList", produces = "text/html;charset=utf-8")
    @ResponseBody
    public String toList(Model model, User user, HttpServletRequest request, HttpServletResponse response) {
        ValueOperations valueOperations = redisTemplate.opsForValue();
        String html = (String) valueOperations.get("schedulesList");
        if (!StringUtils.isEmpty(html)) {
            return html;
        }
        model.addAttribute("user", user);
        model.addAttribute("schedulesList", schedulesService.findSchedulesVo());
        //        如果为空，手动渲染放入Redis并返回
        WebContext context = new WebContext(request, response, request.getServletContext(), request.getLocale(), model.asMap());
        html = thymeleafViewResolver.getTemplateEngine().process("schedulesList", context);
//        需要注入thymeleafViewResolver渲染引擎
        if (!StringUtils.isEmpty(html)) {
            valueOperations.set("schedulesList", html, 10, TimeUnit.SECONDS);
            //设置页面失效时间
        }
        return html;
    }

    @RequestMapping("/toDetail/{scheduleID}")
    @ResponseBody
    public RespBean toDetail(Model model, User user, @PathVariable Integer scheduleID) {
        SchedulesVo schedulesVo = schedulesService.findSchedulesVoById(scheduleID);
        DetailVo detailVo = new DetailVo();
        detailVo.setUser(user);
        detailVo.setSchedulesVo(schedulesVo);
        return RespBean.success(detailVo);
    }

    @RequestMapping("/toCheck")
    public String toCheck(Model model, User user, HttpServletRequest request, HttpServletResponse response) {
        model.addAttribute("user", user);
        model.addAttribute("checkList", schedulesService.findBookVoByCheck(user));
        return "checkList";
    }

    @RequestMapping("/toEdit")
    public String toEdit(Model model, User user, HttpServletRequest request, HttpServletResponse response) {
        model.addAttribute("user", user);
       model.addAttribute("checkList", schedulesService.findBookVoByEdit(user));
        return "editList";
    }
// 原始版本
// @RequestMapping("/toList")
//    public String toList(Model model, User user, HttpServletRequest request, HttpServletResponse response) {
//        model.addAttribute("user", user);
//        model.addAttribute("schedulesList", schedulesService.findSchedulesVo());
//        return "schedulesList";
//    }

}
