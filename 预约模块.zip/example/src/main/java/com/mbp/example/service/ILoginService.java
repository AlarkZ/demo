package com.mbp.example.service;

import com.mbp.example.vo.LoginVo;
import com.mbp.example.vo.RespBean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface ILoginService {
    RespBean doLogin(LoginVo loginVo, HttpServletRequest request, HttpServletResponse response);
}
