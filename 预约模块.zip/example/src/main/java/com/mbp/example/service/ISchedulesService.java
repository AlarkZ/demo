package com.mbp.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mbp.example.pojo.Schedules;
import com.mbp.example.pojo.User;
import com.mbp.example.vo.BookVo;
import com.mbp.example.vo.SchedulesVo;

import java.util.List;

public interface ISchedulesService extends IService<Schedules> {

    List<SchedulesVo> findSchedulesVo();

    SchedulesVo findSchedulesVoById(Integer scheduleID);

    List<BookVo> findBookVoByCheck(User user);

    List<BookVo> findBookVoByEdit(User user);
}
