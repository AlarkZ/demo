package com.mbp.example.vo;

import com.mbp.example.pojo.Schedules;
import lombok.Data;

@Data
public class SchedulesVo extends Schedules {
    private String projectTitle;
    private Integer projectID;

    private String subjectTitle;
    private String teacherName;
    private String labAddress;

}
