package com.mbp.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mbp.example.pojo.Projects;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Alark
 */
public interface IProjectsService extends IService<Projects> {

}
