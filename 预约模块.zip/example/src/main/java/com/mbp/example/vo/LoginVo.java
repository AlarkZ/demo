package com.mbp.example.vo;

import com.mbp.example.validator.IsMobile;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class LoginVo {

    @NotNull
//    @IsMobile
//    手机校验注解
    private String mobile;
    @NotNull
    private String password;
}
