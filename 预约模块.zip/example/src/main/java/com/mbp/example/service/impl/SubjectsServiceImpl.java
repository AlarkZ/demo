package com.mbp.example.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mbp.example.mapper.SubjectsMapper;
import com.mbp.example.pojo.Subjects;
import com.mbp.example.service.ISubjectsService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Alark
 */
@Service
public class SubjectsServiceImpl extends ServiceImpl<SubjectsMapper, Subjects> implements ISubjectsService {

}
