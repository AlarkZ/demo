package com.mbp.example.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user")
public class UserController {
    //用户注册模块
    @RequestMapping("/toRegister")
    public String register() {
        return "register";
    }

}
