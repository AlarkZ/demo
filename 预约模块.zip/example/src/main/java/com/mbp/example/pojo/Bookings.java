package com.mbp.example.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Bookings implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 预约ID
     */
    @TableId(value = "BookingID", type = IdType.AUTO)
    private Integer BookingID;

    /**
     * 课表ID
     */
    @TableField("ScheduleID")
    private Integer ScheduleID;

    /**
     * 用户ID
     */
    @TableField("StudentNO")
    private String StudentNO;

    @TableField("BookingDate")
    private Date BookingDate;

    /**
     * 预约状况：0取消预约，1预约，2已签到，3未签到
     */
    @TableField("BookingStatus")
    private String BookingStatus;

    @TableField("LabID")
    private Integer LabID;

    @TableField("ProjectID")
    private Integer ProjectID;

    @TableField("SubjectID")
    private Integer SubjectID;


}
