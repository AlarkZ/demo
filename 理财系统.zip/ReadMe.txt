1.通过IDEA打开项目SpringBootDemo
2.创建任意数据库，在application.yml中修改配置
3.导入数据库脚本，运行程序
4.通过http://localhost:8080访问，登录页面含管理员账号： admin 密码：123456