package com.demo.service;

import com.demo.pojo.News;

import java.util.List;

public interface NewsService {
    public List<News> selectNewsAll();
}
