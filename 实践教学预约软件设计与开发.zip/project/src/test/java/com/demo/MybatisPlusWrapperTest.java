package com.demo;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.pojo.Schedules;
import com.demo.service.IBookingsService;
import com.demo.service.ISchedulesService;
import com.demo.vo.BookVo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class MybatisPlusWrapperTest {
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private IBookingsService bookingsService;

    @Test
    public void test01() {

        List<Schedules> list = schedulesService.list(new QueryWrapper<Schedules>().orderByDesc("isReleased").orderByAsc("startTime"));
        list.forEach(System.out::println);
    }
    @Test
    public void test02() {
        System.out.println(bookingsService.getSameBook(1, "自组电桥"));
    }
}
