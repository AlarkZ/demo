package com.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.concurrent.*;

@SpringBootTest
public class ThreadPoolTest {

    public static ExecutorService executor = Executors.newFixedThreadPool(10);

    @Test
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        System.out.println("main...start");
        CompletableFuture.supplyAsync(() -> {
            System.out.println("当前线程:" + Thread.currentThread().getId());
            int i = 10 / 2;
            System.out.println("运行结果:" + i);
            return i;
        }, executor).thenRunAsync(() -> {//不接收，无返回值
            System.out.println("任务2启动");
        }, executor);

        CompletableFuture.supplyAsync(() -> {
            System.out.println("当前线程:" + Thread.currentThread().getId());
            int i = 10 / 2;
            System.out.println("运行结果:" + i);
            return i;
        }, executor).thenAcceptAsync(res -> {//接收结果无返回值
            System.out.println("任务2启动 接收值为" + res);
        }, executor);
        CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> {
            System.out.println("当前线程:" + Thread.currentThread().getId());
            int i = 10 / 2;
            System.out.println("运行结果:" + i);
            return i;
        }, executor).thenApplyAsync(res -> {//接收结果无返回值
            System.out.println("任务2启动 " + res);
            return "返回值为hello" + res;
        }, executor);
        System.out.println(future.get());
        /*
        CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
            System.out.println("当前线程:" + Thread.currentThread().getId());
            int i = 10 / 2;
            System.out.println("运行结果:" + i);
        });

        System.out.println("supply...start");
        CompletableFuture<Integer> supplyFuture = CompletableFuture.supplyAsync(() -> {
            System.out.println("当前线程:" + Thread.currentThread().getId());
            int i = 12 / 0;
            System.out.println("运行结果:" + i);
            return i;
        }, executor).whenComplete((res, exception) -> { //能得到异常信息，无法修改返回数据
            System.out.println("异步任务完成 结果是：" + res + "异常是：" + exception);
        }).exceptionally(throwable -> {//异常默认返回值
            return 10;
        }).handle((res, thr) -> {//获取值同时处理异常
            if (res != null) {
                return res * 2;
            }
            if (thr != null) {
                return 0;
            }
            return 0;
        });
        System.out.println(supplyFuture.get());
        */

        System.out.println("main...end");
    }

    @Test
    public void threadPool() {
//        executor.execute();
        ThreadPoolExecutor executor = new ThreadPoolExecutor(5, 200, 10, TimeUnit.SECONDS, new LinkedBlockingDeque<>(100000), Executors.defaultThreadFactory(), new ThreadPoolExecutor.AbortPolicy());

    }
}
