package com.demo;

import org.junit.jupiter.api.Test;
import org.redisson.api.RLock;
import org.redisson.api.RReadWriteLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;
import sun.nio.ch.ThreadPool;

import java.util.UUID;
import java.util.concurrent.*;

@SpringBootTest
class DemoApplicationTests {
    @Autowired
    StringRedisTemplate stringRedisTemplate;
    @Autowired
    RedissonClient redisson;

    @Test
    void contextLoads() {

    }
@Test
public void logback(){
    Logger logger= LoggerFactory.getLogger(this.getClass());
    logger.error("error");
    logger.warn("warn");
    logger.info("info");
    logger.debug("debug");
    logger.trace("trace");
}

    @Test
    public void testStringRedis() {
//        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
////        ops.set("hello","world");
////        System.out.println(ops.get("hello"));
//        Object obj = null;
////        序列化
//        String s = JSON.toJSONString(obj);
////        反序列化
//        Object res = JSON.parseObject(s, new TypeReference<Object>() {
//        });
        System.out.println(redisson);
        //获取一把锁
        RLock lock = redisson.getLock("my-lock");
        lock.lock();//阻塞等待、看门狗自动续期和自动解锁
        System.out.println("加锁");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
            System.out.println("解锁");
        }
    }

    @Test
    public String writeValue() {
        RReadWriteLock lock = redisson.getReadWriteLock("rw-lock");
        RLock wLock = lock.writeLock();
        RLock rLock = lock.readLock();
        rLock.lock();
        rLock.unlock();
        wLock.lock();
        wLock.unlock();

        String s = UUID.randomUUID().toString();

        return s;
    }

    @Test
    public void redissonLock() {
        RLock lock = redisson.getLock("Json-lock");
        lock.lock();
        try {

        } finally {
            lock.unlock();

        }
    }
}
