package com.demo.service;

import com.demo.pojo.Bookings;
import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.pojo.Schedules;
import com.demo.pojo.User;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Alark
 */
public interface IBookingsService extends IService<Bookings> {

    void doBook(User user, Schedules schedulesVo);

    void doCancel(User user, Bookings booking);

    List<Schedules> getSameBook(Integer id, String subjectTitle);

    void doBatchCancel(Integer scheduleID);
}
