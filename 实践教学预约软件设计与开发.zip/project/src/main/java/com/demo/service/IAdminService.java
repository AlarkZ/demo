package com.demo.service;

import com.demo.pojo.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Alark
 */
public interface IAdminService extends IService<Admin> {

}
