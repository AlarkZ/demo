package com.demo.service;

import com.demo.pojo.Schedules;
import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.pojo.User;
import com.demo.vo.BookVo;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Alark
 */
public interface ISchedulesService extends IService<Schedules> {

    List<Schedules> findSchedulesVo();

    List<BookVo> findBookVoByCheck(User user);

    List<BookVo> findBookVoBySign();

    List<BookVo> findBookVoByEdit(User user);

    List<Schedules> filterSchedulesVo();
}
