package com.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.pojo.Schedules;
import com.demo.mapper.SchedulesMapper;
import com.demo.pojo.User;
import com.demo.service.ISchedulesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.vo.BookVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Alark
 */
@Service
public class SchedulesServiceImpl extends ServiceImpl<SchedulesMapper, Schedules> implements ISchedulesService {
    @Autowired
    private SchedulesMapper schedulesMapper;

    @Override
    public List<Schedules> findSchedulesVo() {
//        return schedulesMapper.findSchedulesVo();
        return schedulesMapper.selectList(new QueryWrapper<Schedules>()
                .gt("remainQuantity", 0)
                .gt("startTime",new Date())
                .eq("isReleased", 1)
                .orderByAsc("startTime"));
    }

    @Override
    public List<BookVo> findBookVoByCheck(User user) {
        return schedulesMapper.findBookVoByCheck(user.getId());
    }

    @Override
    public List<BookVo> findBookVoByEdit(User user) {
        return schedulesMapper.findBookVoByEdit(user.getId());
    }

    @Override
    public List<Schedules> filterSchedulesVo() {
        return schedulesMapper.selectList(new QueryWrapper<Schedules>());
    }

    @Override
    public List<BookVo> findBookVoBySign() {
        return schedulesMapper.findBookVoBySign();
    }


}
