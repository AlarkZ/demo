package com.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.demo.pojo.Bookings;
import com.demo.mapper.BookingsMapper;
import com.demo.pojo.Schedules;
import com.demo.pojo.User;
import com.demo.service.IBookingsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.service.ISchedulesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Alark
 */
@Service
public class BookingsServiceImpl extends ServiceImpl<BookingsMapper, Bookings> implements IBookingsService {
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private BookingsMapper bookingsMapper;
    @Autowired
    private RedisTemplate redisTemplate;

    @Transactional
    @Override
    public void doBook(User user, Schedules schedulesVo) {
//        如果redis不可靠，防止重复预约的最后一道防线，
//        Bookings repeat = bookingsMapper.selectOne(new QueryWrapper<Bookings>()
//                .eq("scheduleID", schedulesVo.getScheduleID())
//                .eq("studentNO", user.getId())
//                .eq("bookingStatus", 1));
//        if (repeat != null) {
//            redisTemplate.opsForValue().increment("schedules:" + repeat.getScheduleID());
//            redisTemplate.opsForValue().set("booking:" + repeat.getStudentNO() + ":" + repeat.getScheduleID(), repeat);
//            return;
//        }

        Schedules updateSchedule = schedulesService.getOne(new QueryWrapper<Schedules>().eq("scheduleID", schedulesVo.getScheduleID()));

        updateSchedule.setRemainQuantity(updateSchedule.getRemainQuantity() - 1);
        boolean result = schedulesService.update(new UpdateWrapper<Schedules>()
                .setSql("RemainQuantity=" + "RemainQuantity-1")
                .eq("ScheduleID", schedulesVo.getScheduleID())
                .gt("RemainQuantity", 0));
        ValueOperations valueOperations = redisTemplate.opsForValue();

        if (result == false && updateSchedule.getRemainQuantity() < 1) {//更新失败且库存为0
            valueOperations.set("isStockEmpty:" + schedulesVo.getScheduleID(), "0");//用于异步查询结果
            return;
        }

        Bookings bookings = new Bookings();
        bookings.setScheduleID(schedulesVo.getScheduleID());
        bookings.setStudentNO(user.getId());
        bookings.setBookingStatus("1");
        bookings.setBookingDate(new Date());
        bookingsMapper.insert(bookings);

        valueOperations.set("booking:" + user.getId() + ":" + schedulesVo.getScheduleID(), bookings);
//        valueOperations.set("booking:" + user.getId() + ":" + schedulesVo.getSubjectTitle(), bookings);

    }

    @Transactional
    @Override
    public void doCancel(User user, Bookings booking) {
        if (booking == null) {
            return;
        }
        booking.setBookingStatus("2");
        bookingsMapper.updateById(booking);
        redisTemplate.delete("booking:" + user.getId() + ":" + booking.getScheduleID());
        redisTemplate.delete("isStockEmpty:" + booking.getScheduleID());
        schedulesService.update(new UpdateWrapper<Schedules>().setSql("RemainQuantity=RemainQuantity+1").eq("ScheduleID", booking.getScheduleID()));

    }

    @Override
    public List<Schedules> getSameBook(Integer id, String subjectTitle) {
        return bookingsMapper.getSameBook(id, subjectTitle);
    }

    @Override
    public void doBatchCancel(Integer scheduleID) {
        this.update(new UpdateWrapper<Bookings>().setSql("bookingStatus=2").eq("scheduleID", scheduleID));
        schedulesService.update(new UpdateWrapper<Schedules>().setSql("remainQuantity=upperQuantity").eq("scheduleID", scheduleID));
        Set<String> keys = redisTemplate.keys("booking:*:" + scheduleID);
        if (keys != null) {
            redisTemplate.delete(keys);
        }
    }

}
