package com.demo.service;

import com.demo.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Alark
 */
public interface IUserService extends IService<User> {

    User getUserByCookie(String userTicket, HttpServletRequest request, HttpServletResponse response);
}
