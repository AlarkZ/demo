package com.demo.mapper;

import com.demo.pojo.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Alark
 */
public interface AdminMapper extends BaseMapper<Admin> {

}
