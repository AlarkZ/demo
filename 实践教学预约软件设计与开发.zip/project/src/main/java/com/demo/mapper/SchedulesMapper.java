package com.demo.mapper;

import com.demo.pojo.Schedules;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.vo.BookVo;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Alark
 */
public interface SchedulesMapper extends BaseMapper<Schedules> {
    List<Schedules> findSchedulesVo();

    List<BookVo> findBookVoByCheck(Integer userId);

    List<BookVo> findBookVoBySign();

    List<BookVo> findBookVoByEdit(Integer userId);
}
