package com.demo.mapper;

import com.demo.pojo.Bookings;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.pojo.Schedules;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Alark
 */
public interface BookingsMapper extends BaseMapper<Bookings> {

    List<Schedules> getSameBook(Integer userId, String subjectTitle);
}
