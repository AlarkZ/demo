package com.demo.rabbitmq;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.pojo.BookMessage;
import com.demo.pojo.Bookings;
import com.demo.pojo.Schedules;
import com.demo.pojo.User;
import com.demo.service.IBookingsService;
import com.demo.service.ISchedulesService;
import com.demo.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 消息消费者
 */
@Service
@Slf4j
public class MQReceiver {
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private IBookingsService bookingsService;

    @RabbitListener(queues = "Queue")
    public void receive(String message) {
        BookMessage bookMessage = JsonUtil.jsonStr2Object(message, BookMessage.class);
        Integer scheduleId = bookMessage.getScheduleId();
        User user = bookMessage.getUser();
//        SchedulesVo schedulesVo = schedulesService.findSchedulesVoById(scheduleId);
        Schedules schedulesVo = schedulesService.getOne(new QueryWrapper<Schedules>().eq("scheduleId", scheduleId));
        if (schedulesVo.getRemainQuantity() < 1) {
            return;
        }
        Bookings repeatBook = (Bookings) redisTemplate.opsForValue().get("booking:" + user.getId() + ":" + scheduleId);
        if (repeatBook != null) {
            redisTemplate.opsForValue().set("isStockEmpty:" + schedulesVo.getScheduleID(), "0");
            return;
        }
        List<Schedules> sameBook = bookingsService.getSameBook(user.getId(), schedulesVo.getSubjectTitle());
        if (!sameBook.isEmpty()) {
            redisTemplate.opsForValue().set("booking:" + user.getId() + ":" + schedulesVo.getSubjectTitle(), 0, 60, TimeUnit.SECONDS);
            redisTemplate.opsForValue().increment("schedules:" + scheduleId);
            return;
        }
        bookingsService.doBook(user, schedulesVo);
    }

}
