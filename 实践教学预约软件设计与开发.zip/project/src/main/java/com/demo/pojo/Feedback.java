package com.demo.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_feedback")
public class Feedback implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "feedbackID", type = IdType.AUTO)
    private Integer feedbackID;

    @TableField("bookingID")
    private Integer bookingID;

    @TableField("scheduleID")
    private Integer scheduleID;

    @TableField("studentNO")
    private Integer studentNO;

    @TableField("feedbackDesc")
    private String feedbackDesc;


}
