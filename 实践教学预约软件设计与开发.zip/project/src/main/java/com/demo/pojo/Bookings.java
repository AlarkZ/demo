package com.demo.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_bookings")
public class Bookings implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 预约ID
     */
    @TableId(value = "bookingID", type = IdType.AUTO)
    private Integer bookingID;

    /**
     * 课表ID
     */
    @TableField("scheduleID")
    private Integer scheduleID;

    /**
     * 用户ID
     */
    @TableField("studentNO")
    private Integer studentNO;

    @TableField("bookingDate")
    private Date bookingDate;

    /**
     * 预约状况：1预约，2取消预约，3已签到，4未签到
     */
    @TableField("bookingStatus")
    private String bookingStatus;


}
