package com.demo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_schedules")
public class Schedules implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 课表ID
     */
    @TableId(value = "scheduleID", type = IdType.AUTO)
    private Integer scheduleID;

    /**
     * 剩余数量
     */
    @TableField("remainQuantity")
    private Integer remainQuantity;

    /**
     * 上限数量
     */
    @TableField("upperQuantity")
    private Integer upperQuantity;

    /**
     * 题目名称
     */
    @TableField("subjectTitle")
    private String subjectTitle;

    /**
     * 实验室地址
     */
    @TableField("labAddress")
    private String labAddress;

    /**
     * 教师姓名
     */
    @TableField("teacherName")
    private String teacherName;

    /**
     * 开始时间
     */
    @TableField("startTime")
    private String startTime;

    /**
     * 持续时间
     */
    @TableField("courseTime")
    private Integer courseTime;

    /**
     * 发布状态
     */
    @TableField("isReleased")
    private Integer isReleased;


}
