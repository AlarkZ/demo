package com.demo.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_message")
public class Message implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 消息编号 主键自增
     */
    @TableId(value = "messageId", type = IdType.AUTO)
    private Integer messageId;

    /**
     * 消息接收者id（user）
     */
    @TableField("receiveId")
    private Integer receiveId;

    /**
     * 消息创建时间
     */
    @TableField("createTime")
    private Date createTime;

    /**
     * 消息标题
     */
    private String title;

    /**
     * 消息内容
     */
    @TableField("infoDesc")
    private String infoDesc;

    /**
     * 消息状态（0：未读  1：已读）
     */
    private Integer status;


}
