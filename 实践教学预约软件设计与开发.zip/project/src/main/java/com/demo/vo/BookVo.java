package com.demo.vo;

import com.demo.pojo.Schedules;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookVo extends Schedules {

    private Integer bookingID;
    private String bookingStatus;
    private Integer StudentNO;
    private String userName;
}
