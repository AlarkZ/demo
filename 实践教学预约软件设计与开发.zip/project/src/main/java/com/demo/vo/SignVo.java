package com.demo.vo;

import com.demo.pojo.Bookings;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SignVo extends Bookings {
    private String username;

}
