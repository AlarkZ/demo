package com.demo.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChartVo {
    private Integer remainQuantity;
    private Integer bookQuantity;
    private Integer cancelQuantity;
}
