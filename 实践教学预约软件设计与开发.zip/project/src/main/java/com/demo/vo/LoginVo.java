package com.demo.vo;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class LoginVo {

    @NotNull
//    @IsMobile
//    手机校验注解
    private String mobile;//以手机号作为学号id
    @NotNull
    private String password;
}
