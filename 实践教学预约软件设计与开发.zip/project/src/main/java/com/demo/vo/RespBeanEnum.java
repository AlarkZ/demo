package com.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public enum RespBeanEnum {
    //通用
    SUCCESS(200, "SUCCESS"),
    ERROR(500, "服务端异常"),
    BOOK_SUCCESS(201, "预约成功"),

    //登录模块
    LOGIN_ERROR(500210, "用户名或者密码不正确"),
    MOBILE_ERROR(500211, "手机号码格式不正确"),
    BIND_ERROR(500212, "参数校验异常"),
    MOBILE_NOT_EXIST(500213, "手机号码不存在"),
    PASSWORD_UPDATE_FAIL(500214, "更新密码失败"),
    SESSION_ERROR(500215, "用户SESSION不存在"),
    USER_EXIST(500216,"用户已存在"),


    //预约模块
    EMPTY_STOCK(500500, "课程剩余不足"),
    REPEAT_ERROR(500501, "无法重复预约"),
    REQUEST_ILLEGAL(500502, "请求非法，请重新尝试"),
    ERROR_CAPTCHA(500503, "验证码错误，请重新输入"),
    ACCESS_LIMIT_REACHED(500504, "访问过于频繁，请稍后重试"),
    BOOK_FAIL(500505, "预约失败"),
    SAME_BOOK(500506,"无法预约相同的课程"),

    //预约模块5003xx
    BOOK_NOT_EXIST(500300, "课程不存在"),
    REPEAT_FEEDBACK(500301,"无法重复评价"),
    ;

    private final Integer code;
    private final String message;

}
