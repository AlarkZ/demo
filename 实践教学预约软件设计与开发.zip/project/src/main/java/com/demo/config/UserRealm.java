package com.demo.config;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.pojo.Admin;
import com.demo.pojo.User;
import com.demo.service.IAdminService;
import com.demo.service.IUserService;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;


public class UserRealm extends AuthorizingRealm {
    @Autowired
    private IAdminService adminService;
    @Autowired
    private IUserService userService;

    //执行授权逻辑
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        System.out.println("执行了=>授权");
        return null;
    }

    //执行认证逻辑
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        System.out.println("执行了=>认证");
        //已经从登录获取,shiro不让接触密码
//        UsernamePasswordToken userToken = (UsernamePasswordToken) token;
//        String username = userToken.getUsername();
//        Admin admin = adminService.getOne(new QueryWrapper<Admin>().eq("username", username));
//        if (admin == null) {
//            return null;
//        }
//        //密码认证
//        return new SimpleAuthenticationInfo(admin.getUsername(), admin.getPassword(), "");
//       // return null;

        UsernamePasswordToken userToken = (UsernamePasswordToken) token;
        String username = userToken.getUsername();
        Admin admin = adminService.getOne(new QueryWrapper<Admin>().eq("username", username));
        User user = userService.getOne(new QueryWrapper<User>().eq("mobile", username));
        if (admin != null) {
            return new SimpleAuthenticationInfo(admin.getUsername(), admin.getPassword(), "");
        }
        if (user != null) {
            return new SimpleAuthenticationInfo(user.getMobile(), user.getPassword(), "");
        }
        return null;
    }
}
