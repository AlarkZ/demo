package com.demo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.common.Msg;
import com.demo.pojo.Admin;
import com.demo.pojo.User;
import com.demo.service.IAdminService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
//@RequestMapping("/admin")
public class AdminController {
//    @Autowired
//    private IAdminService adminService;
//
//    @RequestMapping("/userlist")
//    public String selectUserAll(@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
//                                @RequestParam(value = "pageSize", defaultValue = "5") Integer pageSize,
//                                Model model) {
//        PageHelper.startPage(pageNum, pageSize);//必须添加在sql语句之前
//        List<Admin> list = adminService.list(new QueryWrapper<Admin>());
//        //ModelAndView modelAndView=new ModelAndView("userinfo","list",userService.selectUserALL());
//        PageInfo<Admin> pageInfo = new PageInfo<Admin>(list);
//
//        model.addAttribute("userPageInfo", pageInfo);
//        model.addAttribute("list", list);
//        model.addAttribute("activeUrl", "indexActive");
//        model.addAttribute("activeUrl1", "userInfoActive");
//        model.addAttribute("activeUrl2", "userInfoActive");
//        model.addAttribute("username", "username");
//        return "admin/userinfo/userinfo";
//    }
//
//    //增加操作
//    @RequestMapping("/user/addUser")
//    @ResponseBody
//    public Msg insertUser(Admin admin) {
//        if (null != adminService.getOne(new QueryWrapper<Admin>().eq("username", admin.getUsername()))) {
//            return Msg.fail();
//        }
//        boolean i = adminService.save(admin);
//        if (i == true) {
//            return Msg.success();
//        } else {
//            return Msg.fail();
//        }
//    }
//
//    @RequestMapping("/user/getUserById/{id}")
//    @ResponseBody
//    public Msg getUserById(@PathVariable("id") Integer id) {
//        Admin admin = adminService.getById(id);
//        System.out.println(admin);
//        return Msg.success().add("user", admin);
//    }
//
//    //删除操作
//    @RequestMapping("/user/deleteUserById/{id}")
//    @ResponseBody
//    public Msg deleteUserById(@PathVariable("id") Integer id) {
//        boolean i = adminService.removeById(id);
//        if (i == true) {
//            return Msg.success();
//        } else {
//            return Msg.fail();
//        }
//    }
//    //更新操作
//    @RequestMapping("/user/updateUserProfile/{id}")
//    @ResponseBody
//    public Msg updateUserProfile(@PathVariable("id") Integer id, Admin admin) {
//        boolean i = adminService.saveOrUpdate(admin);
//        if (i == true) {
//            return Msg.success();
//        } else {
//            return Msg.fail();
//        }
//    }
}
