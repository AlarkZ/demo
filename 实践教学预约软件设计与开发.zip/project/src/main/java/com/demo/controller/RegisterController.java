package com.demo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.common.Msg;
import com.demo.pojo.Admin;
import com.demo.pojo.User;
import com.demo.service.IAdminService;
import com.demo.service.ILoginService;
import com.demo.service.IUserService;
import com.demo.vo.RespBean;
import com.demo.vo.RespBeanEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class RegisterController {
    @Autowired
    private IUserService userService;

    @RequestMapping("/toRegister")
    public String toRegister() {
        return "register";
    }

    @RequestMapping("/user/toRegister")
    public String toRegisterUser() {
        return "registerUser";
    }


    @RequestMapping("/user/doRegister")
    @ResponseBody
    public RespBean doRegister(@RequestParam("mobile") String mobile,
                               @RequestParam("password") String password) {
        User exist = userService.getOne(new QueryWrapper<User>().eq("mobile", mobile));
        if (exist != null) {
            return RespBean.error(RespBeanEnum.USER_EXIST);
        }
        User user = new User();
        user.setId((int) userService.count()+1);
        user.setMobile(mobile);
        user.setMobile(mobile);
        user.setPassword(password);
        boolean i = userService.save(user);
        if (i == true) {
            return RespBean.success();
        } else {
            return RespBean.error(RespBeanEnum.ERROR);
        }
    }
}
