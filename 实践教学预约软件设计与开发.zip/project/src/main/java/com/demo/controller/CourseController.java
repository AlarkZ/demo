package com.demo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.demo.common.Msg;
import com.demo.pojo.Bookings;
import com.demo.pojo.Schedules;
import com.demo.pojo.User;
import com.demo.service.IBookingsService;
import com.demo.service.ISchedulesService;
import com.demo.vo.ChartVo;
import com.demo.vo.RespBean;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.ParseException;
import java.util.List;

@Controller
public class CourseController {
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private IBookingsService bookingsService;

    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping("/courseList")
    public String selectCourseAll(@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
                                  @RequestParam(value = "pageSize", defaultValue = "5") Integer pageSize,
                                  Model model) {
        PageHelper.startPage(pageNum, pageSize);
        List<Schedules> list = schedulesService.list(new QueryWrapper<Schedules>().orderByDesc("isReleased").orderByAsc("startTime"));

        PageInfo<Schedules> pageInfo = new PageInfo<Schedules>(list);
        model.addAttribute("coursePageInfo", pageInfo);
        model.addAttribute("courseList", list);
        model.addAttribute("activeUrl", "indexActive");
        model.addAttribute("activeUrl1", "userInfoActive");
        model.addAttribute("activeUrl2", "courseInfoActive");
        model.addAttribute("username", "username");
        return "admin/course/courseInfo";
    }

    //增加操作
    @RequestMapping("/course/addCourse")
    @ResponseBody
    public Msg insertCourse(Schedules schedules) {
        schedules.setRemainQuantity(schedules.getUpperQuantity());
        schedules.setIsReleased(1);
        boolean i = schedulesService.save(schedules);
        if (i == true) {
            redisTemplate.opsForValue().set("schedules:" + schedules.getScheduleID(), schedules.getUpperQuantity());
//            redisTemplate.opsForValue().set("schedulesInfo:" + schedules.getScheduleID(), schedules);
            return Msg.success();
        } else {
            return Msg.fail();
        }
    }

    @RequestMapping("/course/getCourseInfoById/{id}")
    @ResponseBody
    public Msg getCourseInfoById(@PathVariable("id") Integer id) {
        Schedules course = schedulesService.getById(id);
        return Msg.success().add("course", course);
    }

    @RequestMapping("/course/updateCourseInfoById/{id}")
    @ResponseBody
    public Msg updateCourseInfoById(Schedules schedules, @PathVariable("id") Integer id) {
        schedules.setScheduleID(id);
        boolean i = schedulesService.updateById(schedules);
        if (i == false) {
            return Msg.fail();
        }
        Schedules schedule = schedulesService.getById(id);
        if (schedule.getIsReleased() == 0) {
            bookingsService.doBatchCancel(schedule.getScheduleID());
            redisTemplate.opsForValue().set("schedules:"+id,schedule.getUpperQuantity());
        }
//            redisTemplate.opsForValue().set("schedulesInfo:" + schedule.getScheduleID(), schedule);
        return Msg.success();
    }

    @RequestMapping("/course/deleteCourseById/{id}")
    @ResponseBody
    public Msg deleteCourseInfoById(Schedules schedules, @PathVariable("id") Integer id) {

        Schedules schedule = schedulesService.getById(id);
        schedule.setIsReleased(0);
        bookingsService.doBatchCancel(id);
        redisTemplate.opsForValue().set("schedules:"+id,schedule.getUpperQuantity());
//        boolean i = schedulesService.updateById(schedules);
        // schedules并没有从前端传送
        //集体取消
        boolean i = schedulesService.update(new UpdateWrapper<Schedules>().set("isReleased", 0).eq("scheduleID", id));

        if (i == false) {
            return Msg.fail();
        }
        return Msg.success();
    }

    @RequestMapping("/course/getCourseChartById/{scheduleID}")
    @ResponseBody
    public RespBean getCourseChartById(Model model, @PathVariable("scheduleID") Integer scheduleID) {
        QueryWrapper<Bookings> queryWrapper = new QueryWrapper<>();
        int count = (int) bookingsService.count(queryWrapper.eq("scheduleID", scheduleID).eq("bookingStatus", 2));
        Schedules schedule = schedulesService.getOne(new QueryWrapper<Schedules>().eq("scheduleID", scheduleID));
        ChartVo chartVo = new ChartVo();
        chartVo.setCancelQuantity(count);
        chartVo.setRemainQuantity(schedule.getRemainQuantity());
        chartVo.setBookQuantity(schedule.getUpperQuantity() - schedule.getRemainQuantity());
        return RespBean.success(chartVo);
    }
}
