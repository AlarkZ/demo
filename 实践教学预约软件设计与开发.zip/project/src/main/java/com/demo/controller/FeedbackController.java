package com.demo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.pojo.Bookings;
import com.demo.pojo.Feedback;
import com.demo.pojo.Schedules;
import com.demo.pojo.User;
import com.demo.service.IBookingsService;
import com.demo.service.IFeedbackService;
import com.demo.service.ISchedulesService;
import com.demo.vo.BookVo;
import com.demo.vo.RespBean;
import com.demo.vo.RespBeanEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Collections;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Alark
 */
@Controller
@RequestMapping("/feedback")
public class FeedbackController {

    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private IBookingsService bookingsService;
    @Autowired
    private IFeedbackService feedbackService;

    @RequestMapping("/feedbackList")
    public String selectFeedbackAll(Model model) {
        List<Feedback> list=feedbackService.list();
        Collections.reverse(list);
        model.addAttribute("feedbackList", list);
        model.addAttribute("activeUrl", "indexActive");
        model.addAttribute("activeUrl1", "financeActive");
        model.addAttribute("activeUrl2", "feedbackActive");
        return "admin/feedback/feedbackList";
    }

    @RequestMapping("/toFeedback/{bookingID}")
    @ResponseBody
    public RespBean toFeedback(Model model, User user, @PathVariable Integer bookingID) {
//        SchedulesVo schedulesVo = schedulesService.findSchedulesVoById(scheduleID);
//        DetailVo detailVo = new DetailVo();
//        detailVo.setUser(user);
//        detailVo.setSchedulesVo(schedulesVo);
        Bookings booking = bookingsService.getById(bookingID);
        Schedules detailVo = schedulesService.getOne(new QueryWrapper<Schedules>().eq("scheduleID", booking.getScheduleID()));
        return RespBean.success(detailVo);
    }

    @RequestMapping(value = "/doFeedback", method = RequestMethod.POST)
    @ResponseBody
    public RespBean doFeedback(Model model, User user, Integer bookingId,Integer scheduleId, String feedbackDesc) {
        if (user == null) {
            return RespBean.error(RespBeanEnum.SESSION_ERROR);
        }
        Feedback one = feedbackService.getOne(new QueryWrapper<Feedback>().eq("bookingID", bookingId));
        if (one != null) {
            return RespBean.error(RespBeanEnum.REPEAT_FEEDBACK);
        }
        Feedback feedback = new Feedback();
        feedback.setFeedbackID((int) (feedbackService.count() + 1));
        feedback.setBookingID(bookingId);
        feedback.setStudentNO(user.getId());
        feedback.setScheduleID(scheduleId);
        feedback.setFeedbackDesc(feedbackDesc);

        boolean i = feedbackService.save(feedback);
        if (i == true) {
            return RespBean.success();
        } else {
            return RespBean.error(RespBeanEnum.ERROR);
        }
    }
}
