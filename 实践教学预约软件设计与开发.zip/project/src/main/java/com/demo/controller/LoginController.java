package com.demo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.common.Msg;
import com.demo.pojo.Admin;
import com.demo.service.IAdminService;
import com.demo.service.ILoginService;
import com.demo.vo.LoginVo;
import com.demo.vo.RespBean;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 登录
 */

@Controller
@Slf4j
public class LoginController {
    @Autowired
    private ILoginService loginService;
    @Autowired
    private IAdminService adminService;

    @RequestMapping("/")
    public String toAdminLogin() {
        SecurityUtils.getSubject().logout();
        return "login";
    }


    @RequestMapping("/login/verifyLogin")
    @ResponseBody
    public Msg adminLogin(@RequestParam("username") String username,
                          @RequestParam("password") String password,
                          HttpServletRequest request) {
//        shiro版
//        Subject subject = SecurityUtils.getSubject();
//        UsernamePasswordToken token = new UsernamePasswordToken(username, password);
//        try {
//            subject.login(token);//shiro认证
//        } catch (IncorrectCredentialsException e) {
//            return Msg.fail();
//        }
//        return Msg.success().add("url", "/admin/index.html");


        SecurityUtils.getSubject().login(new UsernamePasswordToken(username, password));
        Admin admin = adminService.getOne(new QueryWrapper<Admin>().eq("username", username).eq("password", password));
        if (admin != null) {
            request.getSession().setAttribute("username", admin.getUsername());
            return Msg.success().add("url", "/admin/index.html");
        } else {
            return Msg.fail();
        }
    }

    @RequestMapping("/login/toLogin")
    public String toUserLogin() {
        return "loginUser";
    }

    @RequestMapping("/login/doLogin")
    @ResponseBody
    public RespBean doLogin(@Valid LoginVo loginVo, HttpServletRequest request, HttpServletResponse response) {
//        log.info("{}", loginVo);
//        SecurityUtils.getSubject().login(new UsernamePasswordToken(loginVo.getMobile(), loginVo.getPassword()));
        return loginService.doLogin(loginVo, request, response);
    }
}
