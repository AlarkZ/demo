package com.demo.controller;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.demo.common.Msg;
import com.demo.pojo.Bookings;
import com.demo.pojo.Schedules;
import com.demo.service.IBookingsService;
import com.demo.service.ISchedulesService;
import com.demo.vo.BookVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class SignController {

    @Autowired
    private ISchedulesService schedulesService;

    @Autowired
    private IBookingsService bookingsService;

    @RequestMapping("/signList")
    public String selectCourseAll(Model model) {
//        PageHelper.startPage(list.size(),1);
//        PageInfo<BookVo> pageInfo = new PageInfo<BookVo>(list);
//        model.addAttribute("userPageInfo", pageInfo);

        List<BookVo> list = schedulesService.findBookVoBySign();
        model.addAttribute("signList", list);
        model.addAttribute("activeUrl", "indexActive");
        model.addAttribute("activeUrl1", "financeActive");
        model.addAttribute("activeUrl2", "signActive");
        return "admin/sign/signInfo";
    }

    @RequestMapping("/sign/doSignById/{id}")
    @ResponseBody
    public Msg updateCourseInfoById(@PathVariable("id") Integer bookingID) {
        boolean i = bookingsService.update(new UpdateWrapper<Bookings>().setSql("bookingStatus=3").eq("bookingID", bookingID));
        if (i == true) {
            return Msg.success();
        } else {
            return Msg.fail();
        }
    }
}
