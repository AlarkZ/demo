package com.demo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.pojo.Schedules;
import com.demo.pojo.User;
import com.demo.service.ISchedulesService;
import com.demo.service.IUserService;
import com.demo.vo.BookVo;
import com.demo.vo.RespBean;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring5.view.ThymeleafViewResolver;
import org.thymeleaf.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Alark
 */
@Controller
@RequestMapping("/schedules")
public class SchedulesController {

    @Autowired
    private IUserService userService;
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private ThymeleafViewResolver thymeleafViewResolver;
    @Autowired
    private ThreadPoolExecutor executor;

    @RequestMapping(value = "/toList", produces = "text/html;charset=utf-8")
    @ResponseBody
    public String toList(Model model, User user, HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum) {
        ValueOperations valueOperations = redisTemplate.opsForValue();
        String html = (String) valueOperations.get("schedulesList:" + pageNum);
        if (!StringUtils.isEmpty(html)) {
            return html;
        }
        List<Schedules> filterList = schedulesService.list(new QueryWrapper<Schedules>().eq("isReleased", 1).groupBy("subjectTitle"));

        PageHelper.startPage(pageNum, 5);//必须添加在sql语句之前
        List<Schedules> schedulesVo = schedulesService.findSchedulesVo();
        PageInfo<Schedules> pageInfo = new PageInfo<Schedules>(schedulesVo);

        model.addAttribute("userPageInfo", pageInfo);
        model.addAttribute("user", user);
        model.addAttribute("schedulesList", schedulesVo);
        model.addAttribute("filterList", filterList);
        //        如果为空，手动渲染放入Redis并返回
        WebContext context = new WebContext(request, response, request.getServletContext(), request.getLocale(), model.asMap());
        html = thymeleafViewResolver.getTemplateEngine().process("schedulesList", context);
//        需要注入thymeleafViewResolver渲染引擎
        if (!StringUtils.isEmpty(html)) {
            valueOperations.set("schedulesList:" + pageNum, html, 10, TimeUnit.SECONDS);
            //设置页面失效时间
        }
        return html;
    }

    @RequestMapping(value = "/filterList", produces = "text/html;charset=utf-8")
    public String filterList(Model model, User user, HttpServletRequest request, HttpServletResponse response, String subjectTitle) throws ExecutionException, InterruptedException {
        CompletableFuture<Void> filterFuture = CompletableFuture.runAsync(() -> {
            List<Schedules> filterList = (List<Schedules>) redisTemplate.opsForValue().get("filterList");
            if (filterList == null) {
                filterList = schedulesService.list(new QueryWrapper<Schedules>().eq("isReleased", 1).groupBy("subjectTitle"));
                redisTemplate.opsForValue().set("filterList", filterList, 60, TimeUnit.SECONDS);
            }
            model.addAttribute("filterList", filterList);
        }, executor);
        CompletableFuture<Void> schedulesFuture = CompletableFuture.runAsync(() -> {
//        PageHelper.startPage(pageNum, 1);
            List<Schedules> schedulesList = schedulesService.list(new QueryWrapper<Schedules>()
                    .eq("subjectTitle", subjectTitle)
                    .gt("startTime",new Date())
                    .gt("remainQuantity", 0)
                    .eq("isReleased", 1)
                    .orderByAsc("startTime"));
            model.addAttribute("schedulesList", schedulesList);
//        PageInfo<Schedules> pageInfo = new PageInfo<Schedules>(schedulesList);
//        model.addAttribute("userPageInfo", pageInfo);
        }, executor);
        //等待所有线程完成
        CompletableFuture.allOf(filterFuture, schedulesFuture).get();
        return "filterList";
    }

    @RequestMapping("/toCheck")
    public String toCheck(Model model, User user, HttpServletRequest request, HttpServletResponse response) {
        if (user == null) {
            return "loginUser";
        }
        model.addAttribute("user", user);
        model.addAttribute("checkList", schedulesService.findBookVoByCheck(user));
        return "checkList";
    }

    @RequestMapping("/toEdit")
    public String toEdit(Model model, User user, HttpServletRequest request, HttpServletResponse response) {
        if (user == null) {
            return "loginUser";
        }
        List<BookVo> editList = (List<BookVo>) redisTemplate.opsForValue().get("editList:" + user.getId());
        if (editList == null) {
            editList = schedulesService.findBookVoByEdit(user);
            redisTemplate.opsForValue().set("editList:" + user.getId(), editList, 10, TimeUnit.SECONDS);
        }
        model.addAttribute("user", user);
        model.addAttribute("editList", editList);
        return "editList";
    }

    @RequestMapping("/toDetail/{scheduleID}")
    @ResponseBody
    public RespBean toDetail(Model model, User user, @PathVariable Integer scheduleID) {
//        SchedulesVo schedulesVo = schedulesService.findSchedulesVoById(scheduleID);
//        DetailVo detailVo = new DetailVo();
//        detailVo.setUser(user);
//        detailVo.setSchedulesVo(schedulesVo);
//        ValueOperations valueOperations = redisTemplate.opsForValue();
//        Schedules detailVo = (Schedules) valueOperations.get("courses:" + scheduleID);
//        if (detailVo != null) {
//            detailVo.setRemainQuantity((Integer) valueOperations.get("schedules:" + scheduleID));
//        } else {
//            detailVo = schedulesService.getOne(new QueryWrapper<Schedules>().eq("scheduleID", scheduleID));
//            valueOperations.set("courses:" + scheduleID, detailVo);
//        }

        Schedules detailVo = schedulesService.getOne(new QueryWrapper<Schedules>().eq("scheduleID", scheduleID));
        return RespBean.success(detailVo);
    }

//    @RequestMapping("/doFilter")
//    @ResponseBody
//    public RespBean doFilter(Model model, User user, @RequestParam String subjectTitle) {
//        System.out.println(subjectTitle);
//        List<Schedules> filterList = schedulesService.list(new QueryWrapper<Schedules>()
//                .eq("subjectTitle", subjectTitle)
//                .gt("remainQuantity", 0)
//                .eq("isReleased", 1).orderByAsc("startTime"));
//        model.addAttribute("filterList", filterList);
////        schedulesService.filterSchedulesVo();
//        return RespBean.success();
//    }
}
