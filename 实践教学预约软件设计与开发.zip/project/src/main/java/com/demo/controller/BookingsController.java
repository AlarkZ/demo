package com.demo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.pojo.BookMessage;
import com.demo.pojo.Bookings;
import com.demo.pojo.Schedules;
import com.demo.pojo.User;
import com.demo.rabbitmq.MQSender;
import com.demo.service.IBookingsService;
import com.demo.service.ISchedulesService;
import com.demo.utils.IdempotentUtil;
import com.demo.utils.JsonUtil;
import com.demo.utils.UUIDUtil;
import com.demo.vo.RespBean;
import com.demo.vo.RespBeanEnum;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.script.RedisScript;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Alark
 */
@Controller
@RequestMapping("/bookings")
public class BookingsController implements InitializingBean {
    @Autowired
    private ISchedulesService schedulesService;
    @Autowired
    private IBookingsService bookingsService;
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private MQSender mqSender;
    @Autowired
    private RedisScript<Long> redisScript;
    @Autowired
    RedissonClient redissonClient;

    @RequestMapping(value = "/doBook", method = RequestMethod.POST)
    @ResponseBody
    public RespBean doBook(Model model, User user, Integer scheduleId, String subjectTitle, HttpServletRequest request) {
        if (user == null) {
            return RespBean.error(RespBeanEnum.SESSION_ERROR);
        }
//通用接口锁不住
        String uri = request.getRequestURI();
        Integer count = (Integer) redisTemplate.opsForValue().get(uri + ":" + user.getId());
        if (count == null) {
            redisTemplate.opsForValue().set(uri + ":" + user.getId(), 1, 3, TimeUnit.SECONDS);
        } else {
            return RespBean.error(RespBeanEnum.ACCESS_LIMIT_REACHED);
        }
//        String redisPath = (String) redisTemplate.opsForValue().get("bookPath:" + user.getId() + ":" + scheduleId);
//        if (!redisPath.equals(path)) {
//            return RespBean.error(RespBeanEnum.REQUEST_ILLEGAL);
//        }
//        if (EmptyStockMap.get(scheduleId)) {//内存标记存在漏洞
//            return RespBean.error(RespBeanEnum.EMPTY_STOCK);
//        }

        ValueOperations valueOperations = redisTemplate.opsForValue();
        Bookings repeatBook = (Bookings) valueOperations.get("booking:" + user.getId() + ":" + scheduleId);
        if (repeatBook != null) {//重复预约
            return RespBean.error(RespBeanEnum.REPEAT_ERROR, repeatBook);
        }
//        对于多机环境，建议使用分布式锁
//        RLock lock = redissonClient.getLock("book:lock");
//        lock.lock(10, TimeUnit.SECONDS);
//        lock.unlock();

//        List<Schedules> sameBook = bookingsService.getSameBook(user.getId(), subjectTitle);
//        if (!sameBook.isEmpty()) {//相同课程预约
//            return RespBean.error(RespBeanEnum.SAME_BOOK, sameBook);
//        }
//或者LRUMap上锁
        if (!IdempotentUtil.judge(user.getId() + ":" + scheduleId, Bookings.class)) {
            return RespBean.error(RespBeanEnum.ACCESS_LIMIT_REACHED);
        }
        //redis预减存在漏洞
        Long stock = valueOperations.decrement("schedules:" + scheduleId);
//lua脚本方式
//        Long stock = (Long) redisTemplate.execute(redisScript, Collections.singletonList("schedules:" + scheduleId), Collections.EMPTY_LIST);
        if (stock < 0) {
//            EmptyStockMap.put(scheduleId, true);
            valueOperations.increment("schedules:" + scheduleId);
            return RespBean.error(RespBeanEnum.EMPTY_STOCK);
        }
        BookMessage bookMessage = new BookMessage(user, scheduleId);
        mqSender.sendBookMessage(JsonUtil.object2JsonStr(bookMessage));
        return RespBean.success(0);
    }

    @RequestMapping(value = "/getResult", method = RequestMethod.GET)
    @ResponseBody
    public RespBean getResult(User user, Integer scheduleId, String subjectTitle) {
        if (user == null) {
            return RespBean.error(RespBeanEnum.SESSION_ERROR);
        }

//        Integer bookId = bookingsService.getResult(user, scheduleId);
        Integer bookId = 0;
//        Bookings bookings = bookingsService.getOne(new QueryWrapper<Bookings>().eq("StudentNO", user.getId()).eq("ScheduleID", scheduleId).eq("bookingStatus", 1));
        Bookings bookings = (Bookings) redisTemplate.opsForValue().get("booking:" + user.getId() + ":" + scheduleId);
        if (bookings != null) {
            bookId = bookings.getBookingID();
        } else if (redisTemplate.hasKey("isStockEmpty:" + scheduleId)) {//用于异步查询结果
            bookId = -1;
        } else if (redisTemplate.hasKey("booking:" + user.getId() + ":" + subjectTitle)) {
            bookId = -2;
        }
        return RespBean.success(bookId);
    }

    @RequestMapping(value = "/doCancel", method = RequestMethod.POST)
    @ResponseBody
    public RespBean doCancel(User user, Integer bookingId) {
        if (user == null) {
            return RespBean.error(RespBeanEnum.SESSION_ERROR);
        }
        Bookings booking = bookingsService.getOne(new QueryWrapper<Bookings>().eq("BookingID", bookingId).eq("BookingStatus", 1));
        if (booking == null) {
            return RespBean.error(RespBeanEnum.BOOK_NOT_EXIST);
        }
        IdempotentUtil.unLock(user.getId() + ":" + booking.getScheduleID());
        redisTemplate.opsForValue().increment("schedules:" + booking.getScheduleID());
        bookingsService.doCancel(user, booking);
//        EmptyStockMap.put(booking.getScheduleID(), false);
        return RespBean.success();
    }

    @RequestMapping(value = "/getBookPath", method = RequestMethod.GET)
    @ResponseBody
    public RespBean getBookPath(User user, Integer scheduleId, String subjectTitle, HttpServletRequest request) {
        if (user == null) {
            return RespBean.error(RespBeanEnum.SESSION_ERROR);
        }
        String str = UUIDUtil.uuid();
        redisTemplate.opsForValue().set("bookPath:" + user.getId() + ":" + scheduleId, str, 1, TimeUnit.MINUTES);
        return RespBean.success(str);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
//        List<SchedulesVo> list = schedulesService.findSchedulesVo();
        List<Schedules> list = schedulesService.list();
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        list.forEach(schedulesVo -> {
            redisTemplate.opsForValue().set("schedules:" + schedulesVo.getScheduleID(), schedulesVo.getRemainQuantity());
//            redisTemplate.opsForValue().set("courses:" + schedulesVo.getScheduleID(), schedulesVo);
//            EmptyStockMap.put(schedulesVo.getScheduleID(), schedulesVo.getRemainQuantity() > 0 ? false : true);
        });
    }
}
