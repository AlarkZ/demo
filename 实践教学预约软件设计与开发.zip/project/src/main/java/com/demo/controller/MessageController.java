package com.demo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demo.common.Msg;
import com.demo.pojo.Message;
import com.demo.pojo.User;
import com.demo.service.IMessageService;
import com.demo.service.IUserService;
import com.demo.utils.CookieUtil;
import com.demo.utils.UUIDUtil;
import com.demo.vo.RespBean;
import com.demo.vo.RespBeanEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Alark
 */
@Controller
@RequestMapping("/message")
public class MessageController {
    @Autowired
    private IMessageService messageService;
    @Autowired
    private IUserService userService;
    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping("/toMessage")
    public String toCheck(Model model, User user, HttpServletRequest request, HttpServletResponse response) {
        model.addAttribute("user", user);
        List<Message> messageList = messageService.list(new QueryWrapper<Message>().eq("receiveId", user.getId()));
        model.addAttribute("messageList", messageList);
        return "messageList";
    }

    @RequestMapping("/updateUserInfo")
    @ResponseBody
    public RespBean updateInfoById(User user, @RequestParam("password") String password, @RequestParam("username") String username, HttpServletRequest request, HttpServletResponse response) {
        System.out.println(user);
        if (user == null) {
            return RespBean.error(RespBeanEnum.SESSION_ERROR);
        }
        user.setUsername(username);
        user.setPassword(password);
        userService.updateById(user);

        String userTicket = CookieUtil.getCookieValue(request, "userTicket");
        redisTemplate.delete("user:" + userTicket);
        //生成Cookie
        String ticket = UUIDUtil.uuid();
        redisTemplate.opsForValue().set("user:" + ticket, user);
        CookieUtil.setCookie(request, response, "userTicket", ticket);
        return RespBean.success();
    }
}
