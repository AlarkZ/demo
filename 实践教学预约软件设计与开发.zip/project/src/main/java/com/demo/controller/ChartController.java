package com.demo.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ChartController {

}
