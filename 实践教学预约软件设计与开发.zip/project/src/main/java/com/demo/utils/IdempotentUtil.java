package com.demo.utils;


import org.apache.commons.collections4.map.LRUMap;
import org.springframework.stereotype.Component;

@Component
public class IdempotentUtil {
    private static LRUMap<String, Integer> reqCache = new LRUMap<>(100);//太小导致锁不住

    public static boolean judge(String id, Object lockClass) {
        synchronized (lockClass) {//加锁
            if (reqCache.containsKey(id)) {
//                System.out.println("执行失败");
                return false;
            }
//            System.out.println("执行成功");
            reqCache.put(id, 1);
        }
        return true;
    }

    public static void unLock(String id) {//解锁
        reqCache.remove(id);
    }
}
